#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(void)
{
  printf("Initial memory size: %d bytes\n", memsize());

  char *p = malloc(20 * 1024);  // allocate 20KB
  if (p == 0) {
    printf("Failed to allocate memory\n");
    exit(1,"");
  }

  printf("After malloc(20KB): %d bytes\n", memsize());

  free(p);

  printf("After free: %d bytes\n", memsize());

  exit(0,"");
}
