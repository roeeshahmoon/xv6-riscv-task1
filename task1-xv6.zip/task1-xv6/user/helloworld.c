// user/helloworld.c

#include "kernel/types.h"
#include "user/user.h"

int main(void) {
    printf("Hello World xv6\n");
    return 0;
}
