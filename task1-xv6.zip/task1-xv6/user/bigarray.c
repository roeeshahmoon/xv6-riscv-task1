#include "kernel/param.h"
#include "kernel/types.h"
#include "user/user.h"

#define SIZE (1 << 16) // // 2^16 = 65536
#define CHILDREN 4

long arr[SIZE];

void main()
{
    int pids[CHILDREN];
    int statuses[CHILDREN];
    int n;
    int i;
    
    // printf("Starting bigarray\n");
    // Initialize array
    for(i = 0; i < SIZE; i++) {
        arr[i] = i;
    }
    int ret = forkn(CHILDREN, pids);
    if(ret == 0) {
        // printf("%d\n", ret);
        // printf("P\n");    // printf("finish init\n");

        waitall(&n, statuses);
        int total_sum = 0;
        for(i = 0; i < n; i++) {
            printf("Process %d Partial Sum: %d\n", i+1, statuses[i]);
            total_sum += statuses[i];
        }
        printf("Final sum: %d\n", total_sum);
        exit(0, "");
    } 
    else {
        // Child process
        // printf("C\n");
        // printf("%d\n", ret);
        // int mypid = getpid();
        int index = ret - 1;
        int start = (SIZE / CHILDREN) * index;
        int end = start + (SIZE / CHILDREN);
        int partial_sum = 0;
        for (i = start; i < end; i++) {
            partial_sum += arr[i];
        }
        
        if(ret == 1) {
            //i'm child 1
            exit(partial_sum, "");

        } else if(ret == 2) {
            //i'm child 2
            exit(partial_sum, "");

        } else if(ret == 3) {
            //i'm child 3
            exit(partial_sum, "");

        } else{
            //i'm child 4
            exit(partial_sum, "");
        }
    }

}

