#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"

extern struct proc proc[NPROC];
struct proc* forkproc(void);
extern struct spinlock wait_lock;
extern void freeproc(struct proc *p);

uint64
sys_exit(void)
{
  int n;
  uint64 addr;
  argint(0, &n);
  argaddr(1, &addr);
  char msg[32];
  if(argstr(1, msg, sizeof(msg)) < 0)
    return -1;
  exit(n, msg);
  return 0;
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 addr, msgaddr;
  argaddr(0, &addr);
  argaddr(1, &msgaddr);
  return wait(addr, msgaddr);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int n;
  argint(0, &n);
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;
  argint(0, &n);
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;
  argint(0, &pid);
  return kill(pid);
}

uint64
sys_uptime(void)
{
  uint xticks;
  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

uint64
sys_memsize(void)
{
  struct proc *p = myproc();
  return p->sz;
}

uint64
sys_forkn(void)
{
  // printf("sys_forkn start\n");

  int n;
  uint64 pids_ptr;
  struct proc *children[16];
  int kpids[16];
  int i;

  if (argint(0, &n) < 0 || argaddr(1, &pids_ptr) < 0)
    return -1;

  if (n < 1 || n > 16)
    return -1;

  // printf("start forkproc\n");

  for (i = 0; i < n; i++) {
    struct proc *np = forkproc();
    if (np == 0) {
      for (int j = 0; j < i; j++) {
        freeproc(children[j]);
      }
      return -1;
    }
    np->parent = myproc();
    children[i] = np;
    kpids[i] = np->pid;
    // printf("kpids[i]: %d\n", kpids[i]);
    // printf("kpids[i]: %d\n", children[i]->pid);
  }

  if (copyout(myproc()->pagetable, pids_ptr, (char *)kpids, n * sizeof(int)) < 0) {
    for (i = 0; i < n; i++) {
      freeproc(children[i]);
    }
    return -1;
  }

  for (i = 0; i < n; i++) {
    if(children[i]->lock.locked){
      release(&children[i]->lock);
    }
    // printf("for loop i: %d\n", i);
    acquire(&children[i]->lock);
    children[i]->trapframe->a0 = i + 1; // child returns i+1
    children[i]->state = RUNNABLE;
    release(&children[i]->lock);
  }
  myproc()->trapframe->a0 = 0; // parent returns 0
  return 0;

  // if (myproc()->trapframe->a0 == 0) {
  //   // Parent
  //   printf("I'm a parent! pid=%d parent number=%d\n", myproc()->pid, myproc()->trapframe->a0);
  //   return 0;
  // } else {
  //   // Child
  //   printf("I'm a child! pid=%d child number=%d\n", myproc()->pid, myproc()->trapframe->a0);
  //   return myproc()->trapframe->a0;
  // }
}


uint64
sys_waitall(void)
{
  int *n_ptr;        // user pointer to number
  int *statuses_ptr; // user pointer to statuses array
  struct proc *p = myproc();
  int finished = 0;
  int statuses[NPROC]; // temporary kernel array
  // int i;

  // Fetch arguments from user
  if (argaddr(0, (uint64 *)&n_ptr) < 0 || argaddr(1, (uint64 *)&statuses_ptr) < 0)
    return -1;
  // printf("sys_waitall start\n");
  for (;;) {
    int have_children = 0;
    acquire(&wait_lock);
    // printf("sys_waitall loop start\n");
    for (struct proc *child = proc; child < &proc[NPROC]; child++) {
      if (child->parent == p) {
        have_children = 1;
        acquire(&child->lock);
        if (child->state == ZOMBIE) {
          // Save the status
          statuses[finished++] = child->xstate;
          // printf("sys_waitall: child %d finished with status %d\n", child->pid, child->xstate);

          // Free the child
          // pid = child->pid;
          freeproc(child);
          release(&child->lock);
        } else {
          release(&child->lock);
        }
      }
    }
    release(&wait_lock);

    if (have_children == 0) {
      // printf("sys_waitall: no children found\n");
      // No children found
      if (copyout(p->pagetable, (uint64)n_ptr, (char *)&finished, sizeof(int)) < 0)
        return -1;
      if (copyout(p->pagetable, (uint64)statuses_ptr, (char *)statuses, finished * sizeof(int)) < 0)
        return -1;
      return 0;
    }
    // sleep(p, &wait_lock); // Wait until someone changes state
  }
}
